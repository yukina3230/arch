# plymouth-theme-archlinux

Plymouth theme for Arch Linux (Similar to Manjaro)
